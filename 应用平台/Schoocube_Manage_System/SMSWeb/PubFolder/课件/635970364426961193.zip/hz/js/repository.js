$(function(){
	//教育学部显示隐藏
	$('.choiceversion').find('.selected').click(function(){
		clickTab($('.choiceversion'),'.icon');		
	})
	//menu显示隐藏
	$('.grade').find('.item').click(function(){		
		clickTab($('.grade'),'.icon_right');	
	});
	function clickTab(tabObj,transformObj){
		var $contentbox = tabObj.find('.contentbox');
		if($contentbox.is(':hidden')){
			$contentbox.show();
			tabObj.find(transformObj).css('transform','rotate(180deg)');
		}else{
			$contentbox.hide();
			tabObj.find(transformObj).css('transform','rotate(0deg)');
		}
	}
	//鼠标划过批量操作
	$('.operate').hover(function(){
		$(this).find('.operate_wrap').show();
	},function(){
		$(this).find('.operate_wrap').hide();
	})
	//menu折叠展开 选中切换
	/*$('.items').find('.item_title').click(function(){
		$(this).find('.icon').toggleClass('active');
		$(this).next().stop().slideToggle();
		$('.items').find('.contentbox').not($(this).next()).slideUp();
		$('.items .units .item_title .icon').not($(this).children('.icon')).removeClass('active');
	});*/
	$('.items').find('.units').each(function(){
		var oLi = $('.items').find('li')
		oLi.click(function(){
			oLi.removeClass('active');
			$(this).addClass('active');
		});
		$(this).find('.item_title').click(function(){
			var $next = $(this).next();
			var $icon = $(this).find('.icon');
			$icon.toggleClass('active');
			$next.stop().slideToggle();
			$('.items').find('.contentbox').not($next).slideUp();
			$('.items').find('.icon').not($icon).removeClass('active');
		})
	})
	//教案切换、
	$('.docu_item a').click(function(){
		$(this).addClass('on').siblings().removeClass('on');
	})
	//筛选
	$('.selection').click(function(){
		$('.selectionwrap').show();
	})
	//列表页与图标页切换
	$('.list_grid_switch').find('a').click(function(){
		$(this).addClass('on').siblings().removeClass('on');
		var n = $(this).index();
		$('.docu_content>ul').eq(n).show().siblings().hide();
	})
	//列表页与图标页每项划过显示
	function hoverShow(hoverObj,showObj){
		hoverObj.hover(function(){
			hoverObj.find(showObj).hide();
			$(this).find(showObj).show();
			$(this).addClass('active').siblings().removeClass('active');
		},function(){
			hoverObj.removeClass('active');
			hoverObj.find(showObj).hide();
			showObj.find('.arrow_downwrap').hide();
		});
		showObj.find('.arrow-down').click(function(){
			$(this).find('.arrow_downwrap').show();
		});
	}
	hoverShow($('.document_list li'),$('.unload_none'));
	hoverShow($('.docu_grid li'),$('.checkbox'));
	//删除
	function deleted(deleteObj){
		deleteObj.click(function(){
			$(this).parents('li').remove();
		});
	}
	deleted($('.arrow_downwrap .delete'));
	//重命名
	$('.arrow_downwrap .rename').click(function(){
		var renameObj = $(this).parents('li').find('.docu_title');
		var text = renameObj.clone().text();
		renameObj.html('<span class="g-ico g-ico-doctype-doc"></span><input type="text" name="" id="rename" value="'+text+'"/><span class="sure"></span><span class="cancal"></span>');
		//确定
		$('.sure').click(function(){
			var name = $('#rename').val();
			renameObj.html('<span class="g-ico g-ico-doctype-doc"></span><a class="docu_name" href="">'+name+'</a>');
		});
		//取消
		$('.cancal').click(function(){
			renameObj.html('<span class="g-ico g-ico-doctype-doc"></span><a class="docu_name" href="">'+text+'</a>');
		});
	});	
	//stars评价
	$('.assess').each(function(){
		$(this).find('span').click(function(){
			$(this).siblings().removeClass('on');
			$(this).prevAll().andSelf().addClass('on');
		});
	})
})


